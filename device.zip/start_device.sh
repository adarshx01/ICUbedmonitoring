gnome-terminal -- bash -c "python ecg.py" &
gnome-terminal -- bash -c "./rtsp_sink.sh" &
