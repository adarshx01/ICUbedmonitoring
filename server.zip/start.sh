gnome-terminal -- bash -c "./mediamtx" &
gnome-terminal -- bash -c "python models/emotions_api.py" &
